from django.test import TestCase

# from django.test import SimpleTestCase
# from django.urls import reverse, resolve
# from .views import SummarizeView, IndexView, login_view, signup_view

# class TestUrls(SimpleTestCase):
    
#     def test_index_url_resolves(self):
#         url = reverse('index')
#         self.assertEqual(resolve(url).func.view_class, IndexView)

#     def test_summarize_url_resolves(self):
#         url = reverse('summarize')
#         self.assertEqual(resolve(url).func.view_class, SummarizeView)

#     def test_login_url_resolves(self):
#         url = reverse('login')
#         self.assertEqual(resolve(url).func, login_view)

#     def test_signup_url_resolves(self):
#         url = reverse('signup')
#         self.assertEqual(resolve(url).func, signup_view)

# Create your tests here.

# from django.test import TestCase, RequestFactory
# from django.contrib.auth.models import User
# from .views import login_view, signup_view, IndexView, SummarizeView
# import json

# class ViewTestCase(TestCase):

#     def setUp(self):
#         self.factory = RequestFactory()
#         self.user = User.objects.create_user(username='testuser', password='testpass')

#     def test_login_view(self):
#         data = {'email': 'testuser', 'password': 'testpass'}
#         request = self.factory.post('/login/', json.dumps(data), content_type='application/json')
#         response = login_view(request)
#         self.assertEqual(response.status_code, 200)
#         self.assertEqual(response.json(), {'status': 'success'})

#     def test_signup_view(self):
#         data = {'email': 'newuser', 'password': 'newpass', 'name': 'New User'}
#         request = self.factory.post('/signup/', json.dumps(data), content_type='application/json')
#         response = signup_view(request)
#         self.assertEqual(response.status_code, 200)
#         self.assertEqual(response.json(), {'status': 'success'})

#     def test_index_view(self):
#         request = self.factory.get('/')
#         response = IndexView.as_view()(request)
#         self.assertEqual(response.status_code, 200)
#         self.assertTemplateUsed(response, 'api/index.html')

#     def test_summarize_view(self):
#         self.client.login(username='testuser', password='testpass')
#         data = {'text': 'This is a sample text', 'min_length': 50, 'max_length': 100}
#         response = self.client.post('/summarize/', data)
#         self.assertEqual(response.status_code, 200)
#         self.assertIn('summary', response.json())

